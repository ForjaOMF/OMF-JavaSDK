package open.movilforum.autowpapi;

import javax.swing.JOptionPane;


public class TestAutoWP {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		 String Login = JOptionPane.showInputDialog("N�mero de tel�fono (login)", "");
		 String Pwd = JOptionPane.showInputDialog("Password","");
		 String URL = JOptionPane.showInputDialog("URL","");
		 String Text = JOptionPane.showInputDialog("Mensaje","");
		 
		// Inicio conexi�n http		
		AutoWP oSmsSenderHttps = new AutoWP();
		System.out.println(oSmsSenderHttps.sendAutoWP(Login, Pwd, URL, Text));
		
	}
}
