package open.movilforum.copiagendaapi;

import javax.swing.JOptionPane;
import java.util.List;

public class TestCopiagenda {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String login = JOptionPane.showInputDialog("Login", "");
		String pwd = JOptionPane.showInputDialog("Password", "");

		Copiagenda oCopiagenda = new Copiagenda();
		List<String> contactList = oCopiagenda.RetrieveContacts(login, pwd);
		
		if (contactList != null && contactList.size()> 1) {
    		
    		for (int i = 0; i < contactList.size(); i++) {
            	try {
            		System.out.println(contactList.get(i).toString());		                		
            	}
            	catch(Exception e){
            		System.out.println("Failed to read the contact list");
            	}
            }
    	}
		// b�squeda de contactos por nombre
		String sContactoBuscado = JOptionPane.showInputDialog("Buscar por nombre", "");
		String sContactoEncontrado = oCopiagenda.SearchByName(sContactoBuscado,contactList);
		if (sContactoEncontrado != null) {
			String sTel [] = sContactoEncontrado.replaceAll("\"", "").split(",");
			JOptionPane.showMessageDialog(null, "Nombre: " + sContactoBuscado + "\nTel�fono: " + sTel [11],"Contacto encontrado",JOptionPane.INFORMATION_MESSAGE);
		}else {
			JOptionPane.showMessageDialog(null, sContactoBuscado + " no se encuentra en la agenda.","Contacto no encontrado",JOptionPane.ERROR_MESSAGE);
		}
		
	}
}
