package open.movilforum.localizameapi;

import javax.swing.JOptionPane;

public class TestLocalizame {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String login = JOptionPane.showInputDialog("Login", "");
		String pwd = JOptionPane.showInputDialog("Password", "");
		String authorizeNumber = "";
		String unAuthorizeNumber = "";
		String searchNumber = "";
		
		Localizame oLocalizame = new Localizame();
		oLocalizame.Login(login, pwd);
		
		authorizeNumber =JOptionPane.showInputDialog("Authorize number", "");
		if((authorizeNumber != "") && (authorizeNumber != null)) {
			// Authorizes user to locale
			oLocalizame.Authorize(authorizeNumber);
		}
		
		unAuthorizeNumber =JOptionPane.showInputDialog("UnAuthorize number", "");
		if((unAuthorizeNumber != "") && (unAuthorizeNumber != null)) {
			// Unauthorizes user to locale
			oLocalizame.Unauthorize(unAuthorizeNumber);
		}
		
		searchNumber =JOptionPane.showInputDialog("Search number", "");
		if((searchNumber != "") && (searchNumber != null)) {
			// Search location of a user
			oLocalizame.Locate(searchNumber);
		}
				
		// Logs out from server
		oLocalizame.Logout();
	}
}
