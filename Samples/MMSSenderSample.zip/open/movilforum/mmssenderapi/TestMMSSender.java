package open.movilforum.mmssenderapi;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.*;

public class TestMMSSender {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String login = JOptionPane.showInputDialog("Login", "");
		String pwd = JOptionPane.showInputDialog("Password", "");
		String csObjPathImg = "";
		String csObjPathAudio = "";
		String csObjPathVideo = "";
		int seleccion;
		FileFilter imageFilter = new ImageFilter();
		FileFilter audioFilter = new AudioFilter();
		FileFilter videoFilter = new VideoFilter();
		
		MMSSender oMMSSender = new MMSSender();
		if(oMMSSender.Login(login, pwd) == "") {
			System.out.println("Username or password not valid");
		}
		
		JFileChooser fileChooser = new JFileChooser();
		// Aplica el filtro de imagen
		fileChooser.setFileFilter(imageFilter);
		// selecciona imagen a insertar
		fileChooser.setDialogTitle("Select image");
		seleccion = fileChooser.showOpenDialog(null); 
		if (seleccion == JFileChooser.APPROVE_OPTION) {			
			csObjPathImg = fileChooser.getSelectedFile().getPath();
			oMMSSender.InsertImage(csObjPathImg);
		}
		// Borra el filtro de archivos de imagen
		fileChooser.removeChoosableFileFilter(imageFilter);
		
		// Aplica el filtro de audio
		fileChooser.setFileFilter(audioFilter);
		// selecciona fichero de audio a insertar
		fileChooser.setDialogTitle("Select audio");
		seleccion = fileChooser.showOpenDialog(null); 
		if (seleccion == JFileChooser.APPROVE_OPTION) {			
			csObjPathAudio = fileChooser.getSelectedFile().getPath();
			oMMSSender.InsertAudio(csObjPathAudio);
		}
		// Borra el filtro de archivos de audio
		fileChooser.removeChoosableFileFilter(audioFilter);
		// Aplica el filtro de video
		fileChooser.setFileFilter(videoFilter);
		// selecciona video a insertar
		fileChooser.setDialogTitle("Select video");
		seleccion = fileChooser.showOpenDialog(null); 
		if (seleccion == JFileChooser.APPROVE_OPTION) {			
			csObjPathVideo = fileChooser.getSelectedFile().getPath();
			oMMSSender.InsertVideo(csObjPathVideo);
		}
		
		String Subject = JOptionPane.showInputDialog("Subject", "");
		String Dest = JOptionPane.showInputDialog("To", "");
		String Msg = JOptionPane.showInputDialog("Message", "");
		
		// env�a el MMS
		oMMSSender.SendMessage(Subject, Dest, Msg);
		
		// cierra sesi�n
		if (oMMSSender.Logout()==true) {
			System.out.println("logout");
		}
	}
}
