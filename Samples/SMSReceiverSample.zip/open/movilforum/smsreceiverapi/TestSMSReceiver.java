package open.movilforum.smsreceiverapi;

import java.util.Iterator;
import java.util.List;
import javax.mail.Message;
import javax.swing.JOptionPane;

public class TestSMSReceiver {
  
	public static void main(String[] args) {
	
		String Server = JOptionPane.showInputDialog("Server","");
	    String Login    = JOptionPane.showInputDialog("Login", "");
	    String Password = JOptionPane.showInputDialog("Password","");
	    
	    SMSReceiver oSMSReceiver = new SMSReceiver();
	    
		try {
	      
	    	List<Message> mailList = oSMSReceiver.GetSMSList( Server, Login, Password);
	    	
	    	Iterator<Message> mails = mailList.iterator();
			Message message =  null;
			
			while(mails.hasNext()) {
				message = (Message) mails.next();				
				String from = oSMSReceiver.readFrom(message);
				String body = oSMSReceiver.readBody(message);
				String subject = oSMSReceiver.readSubject(message);
				
				try {
					JOptionPane.showMessageDialog(null,"-Subject:\n\t" + subject + "\n\t" + "-From:\n\t" + from +"\n\t" +"-Body:\n\t" + body, "Test SMS Receiver", JOptionPane.PLAIN_MESSAGE);
				} catch( Exception e ) {
					System.out.println("Failed to display the message");
				}  
				
			}

		} catch (Exception e) {
			System.out.println("Unable to connect to server: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
