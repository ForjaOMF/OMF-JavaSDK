package open.movilforum.smssenderapi;

import javax.swing.JOptionPane;


public class TestSMSSender {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		 String Login = JOptionPane.showInputDialog("N�mero de tel�fono (login)", "");
		 String Pwd = JOptionPane.showInputDialog("Password","");
		 String Dest = JOptionPane.showInputDialog("Destino","");
		 String Msg = JOptionPane.showInputDialog("Mensaje","");
		 
		// Inicio conexi�n https		
		SMSSender oSmsSenderHttps = new SMSSender();
		System.out.println(oSmsSenderHttps.SendMessage(Login, Pwd, Dest, Msg));
		
	}
}
